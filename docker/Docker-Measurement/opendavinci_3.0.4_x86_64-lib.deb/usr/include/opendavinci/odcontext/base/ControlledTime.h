/**
 * OpenDaVINCI - Portable middleware for distributed components.
 * Copyright (C) 2008 - 2015 Christian Berger, Bernhard Rumpe
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

#ifndef CONTEXT_BASE_CONTROLLEDTIME_H_
#define CONTEXT_BASE_CONTROLLEDTIME_H_

#include "opendavinci/odcore/opendavinci.h"
#include "opendavinci/odcore/wrapper/Time.h"

namespace odcontext {
    namespace base {

        /**
         * This class provides a controlled time.
         */
        class OPENDAVINCI_API ControlledTime : public odcore::wrapper::Time {
            public:
                ControlledTime();

                /**
                 * Constructor.
                 *
                 * @param s Seconds.
                 * @param ps Partial microseconds.
                 */
                ControlledTime(const uint32_t &s, const uint32_t &ps, const uint32_t &ns);

                /**
                 * Copy constructor.
                 *
                 * @param ct Object from same class.
                 */
                ControlledTime(const ControlledTime &ct);

                virtual ~ControlledTime();

                /**
                 * Assignment operator.
                 *
                 * @param ct Object from same class.
                 * @return (*this).
                 */
                ControlledTime& operator=(const ControlledTime &ct);

                virtual int32_t getSeconds() const;

                virtual int32_t getPartialMicroseconds() const;

                virtual int32_t getPartialNanoseconds() const;

                /**
                 * This method sets the seconds.
                 *
                 * @param s Seconds.
                 */
                void setSeconds(const int32_t &s);

                /**
                 * This method sets the partial microseconds.
                 *
                 * @param partialMS Partial microseconds.
                 */
                void setPartialMicroseconds(const int32_t &partialMS);

                /**
                 * This method sets the partial nanoseconds.
                 *
                 * @param partialNS Partial nanoseconds.
                 */
                void setPartialNanoseconds(const int32_t &partialNS);

            private:
                int32_t m_seconds;
                int32_t m_partialMicroseconds;
                int32_t m_partialNanoseconds;
        };

    }
} // odcontext::base

#endif /*CONTEXT_BASE_CONTROLLEDTIME_H_*/
